import org.testng.Assert;
import org.testng.annotations.Test;

public class SingleTest extends BaseTest{

    private static final String stringForSearch = "Xiaomi";
    private static final String expectdText = "Xiaomi";
    private static final int totalFoundElemets = 12;

    @Test
    public void searchResultTest (){
        getHomePage().searchItems(stringForSearch);
        for (int i = 0; i < searchResultPage().searcResultList().size() ; i++) {
            System.out.println(searchResultPage().searcResultList().get(i).getText());
        Assert.assertTrue(getDriver().getCurrentUrl().contains(expectdText),stringForSearch);
    }
    }

}
