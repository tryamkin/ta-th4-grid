import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.SearchResultPage;

import static io.github.bonigarcia.wdm.WebDriverManager.chromedriver;

public class BaseTest {

    private WebDriver driver;
    private final String url = "https://avic.ua";

    @BeforeTest
    public void setupProfile() {
        chromedriver().setup();
    }
    @BeforeMethod
    public void setupTest() throws InterruptedException {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get(url);
        Thread.sleep(500);
    }
    @AfterMethod
    public void quit() {
        driver.quit();
    }
    @Test(priority = 1)
    public void firstLaunch() {
        Reporter.log("We used Google Chrome this test");
        Assert.assertEquals("https://avic.ua", url);
        System.out.println(driver.getTitle() + "  Title");
    }
    public WebDriver getDriver() {
        return driver;
    }
    public HomePage getHomePage (){
        return new HomePage(getDriver());
    }

    public SearchResultPage searchResultPage(){
        return new SearchResultPage(getDriver());
    }

}
