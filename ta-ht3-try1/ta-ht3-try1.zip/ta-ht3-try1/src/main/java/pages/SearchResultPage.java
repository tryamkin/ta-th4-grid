package pages;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import java.util.List;

public class SearchResultPage extends MainPage{
    private static final String searchResult = "//div[@class='prod-cart__descr']";

    public SearchResultPage(WebDriver driver) {
        super(driver);
    }

    public  List<WebElement>  searcResultList (){
        return driver.findElements(By.xpath(searchResult));
    }

    public int sizeOfsearcResultList(){
       return searcResultList().size();
    }

}
