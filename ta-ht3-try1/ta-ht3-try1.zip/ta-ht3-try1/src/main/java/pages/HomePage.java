package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomePage extends MainPage{
    @FindBy (xpath = "//input[@id='input_search']")
    private WebElement SEARCH_FIELD;
    @FindBy( xpath ="//button[@type='submit']//i[@class='icon icon-search']" )
    private WebElement SEARCH_BUTTON;
    //private static final String searchField = "//input[@id='input_search']";
    //private static final String searchButton = "//button[@type='submit']//i[@class='icon icon-search']";

    public HomePage(WebDriver driver) {
        super(driver);
    }

    public void searchItems (String stringForSearch){
      SEARCH_FIELD.sendKeys(stringForSearch);
      SEARCH_BUTTON.click();
      // driver.findElement(By.xpath(SEARCH_FIELD)).sendKeys(stringForSearch);
      // driver.findElement(By.xpath(searchButton)).click();
    }

}
